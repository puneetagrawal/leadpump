# Rails.application.config.middleware.use OmniAuth::Builder do
#    provider :facebook, ‘431721766939848’, ‘2de25ad6eb3cbedb99e846ef05dad858’
# end