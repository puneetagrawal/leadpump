Stripe.api_key  = "sk_test_MDqPbXEEDmOnzrqwJhyzmYeF"
STRIPE_PUBLIC_KEY = "pk_test_khzNUZcEtnlUCiom3lA2nQtI"