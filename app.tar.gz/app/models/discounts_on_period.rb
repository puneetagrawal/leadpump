class DiscountsOnPeriod < ActiveRecord::Base
  attr_accessible :discountPercentage, :periodType
end
