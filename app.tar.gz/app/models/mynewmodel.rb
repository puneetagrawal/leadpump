class Mynewmodel < ActiveRecord::Base
  attr_accessible :string, :string
end
