module CompanyHelper
end
